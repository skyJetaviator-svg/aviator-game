const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 400;
canvas.height = 300;

let planeY = 150;
let speed = 0;
let isFlying = false;

document.getElementById("startBtn").addEventListener("click", () => {
  isFlying = true;
  speed = 2 + Math.random() * 5; // র‍্যান্ডম স্পিড
  document.getElementById("status").innerText = "Plane is flying...";
  gameLoop();
});

function gameLoop() {
  if (!isFlying) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // প্লেন আঁকা
  ctx.fillStyle = "red";
  ctx.fillRect(50, planeY, 40, 20);

  // প্লেন মুভ করা
  planeY -= speed * 0.5;

  // যদি প্লেন ক্যানভাসের বাইরে চলে যায়
  if (planeY < -20) {
    isFlying = false;
    document.getElementById("status").innerText = "💥 Plane crashed!";
    return;
  }

  requestAnimationFrame(gameLoop);
}