let multiplier = 1.00;
let balance = 1000;
let gameInterval;
let crashPoint;
let isPlaying = false;

const plane = document.getElementById("plane");
const multiplierDisplay = document.getElementById("multiplier");
const balanceDisplay = document.getElementById("balance");
const betInput = document.getElementById("bet-amount");
const startBtn = document.getElementById("start-btn");
const cashoutBtn = document.getElementById("cashout-btn");
const resultDisplay = document.getElementById("result");

startBtn.addEventListener("click", startGame);
cashoutBtn.addEventListener("click", cashOut);

function startGame() {
  const bet = parseInt(betInput.value);
  if (isPlaying || isNaN(bet) || bet <= 0 || bet > balance) {
    alert("Enter a valid bet amount!");
    return;
  }

  // Reset
  multiplier = 1.00;
  multiplierDisplay.textContent = multiplier.toFixed(2);
  resultDisplay.textContent = "";
  plane.style.left = "10px";
  plane.style.top = "150px";

  crashPoint = (Math.random() * 5 + 1).toFixed(2); // crash between x1.00 and x6.00
  isPlaying = true;
  startBtn.disabled = true;
  cashoutBtn.disabled = false;

  gameInterval = setInterval(() => {
    multiplier += 0.05;
    multiplierDisplay.textContent = multiplier.toFixed(2);

    // Move plane
    let left = parseFloat(plane.style.left);
    let top = parseFloat(plane.style.top);
    plane.style.left = left + 10 + "px";
    plane.style.top = top - 3 + "px";

    if (multiplier >= crashPoint) {
      gameOver(false, bet);
    }
  }, 200);
}

function cashOut() {
  const bet = parseInt(betInput.value);
  const winnings = (bet * multiplier).toFixed(2);
  balance += parseFloat(winnings);
  balanceDisplay.textContent = balance.toFixed(2);
  gameOver(true, winnings);
}

function gameOver(won, amount) {
  clearInterval(gameInterval);
  isPlaying = false;
  startBtn.disabled = false;
  cashoutBtn.disabled = true;

  if (won) {
    resultDisplay.textContent = `✅ You cashed out $${amount}`;
  } else {
    const bet = parseInt(betInput.value);
    balance -= bet;
    balanceDisplay.textContent = balance.toFixed(2);
    resultDisplay.textContent = `💥 Plane crashed at x${multiplier.toFixed(2)}! You lost $${bet}`;
  }
}