const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

canvas.width = 400;
canvas.height = 500;

let plane = { x: 180, y: 400, width: 40, height: 40, speed: 5 };
let obstacles = [];
let score = 0;

// Draw plane
function drawPlane() {
  ctx.fillStyle = "red";
  ctx.fillRect(plane.x, plane.y, plane.width, plane.height);
}

// Draw obstacles
function drawObstacles() {
  ctx.fillStyle = "black";
  for (let o of obstacles) {
    ctx.fillRect(o.x, o.y, o.width, o.height);
  }
}

// Update obstacles
function updateObstacles() {
  for (let o of obstacles) {
    o.y += 3;
    if (o.y > canvas.height) {
      obstacles.splice(obstacles.indexOf(o), 1);
      score++;
      document.getElementById("score").innerText = "Score: " + score;
    }
    // Collision
    if (
      plane.x < o.x + o.width &&
      plane.x + plane.width > o.x &&
      plane.y < o.y + o.height &&
      plane.y + plane.height > o.y
    ) {
      alert("Game Over! Final Score: " + score);
      document.location.reload();
    }
  }
}

// Controls
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft" && plane.x > 0) plane.x -= plane.speed;
  if (e.key === "ArrowRight" && plane.x < canvas.width - plane.width)
    plane.x += plane.speed;
});

// Spawn obstacles
setInterval(() => {
  let x = Math.random() * (canvas.width - 40);
  obstacles.push({ x: x, y: 0, width: 40, height: 40 });
}, 1500);

// Game loop
function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPlane();
  drawObstacles();
  updateObstacles();
  requestAnimationFrame(gameLoop);
}

gameLoop();
